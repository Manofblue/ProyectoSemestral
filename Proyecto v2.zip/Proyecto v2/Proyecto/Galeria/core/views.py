from django.shortcuts import render, redirect, get_object_or_404
from .models  import *
from .forms import *
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import Group
from rest_framework import viewsets
from .serializers import *
from rest_framework.renderers import JSONRenderer
import os
import requests

#Metodos para listar desde el api
def empleadosapi(request):
    response = requests.get('https://api.artic.edu/api/v1/artworks?page=2&limit=100')
    artworks = response.json()
    aux = {
        'lista' : artworks['data']
    }

    return render(request,'core/Imagenes/crudapi/index.html', aux)

def dineroapi(request):
    response = requests.get('https://mindicador.cl/api')
    dinero = response.json()
    aux = {
        'lista' : dinero
    }
    return render(request,'core/Imagenes/crudapi/detalle.html', aux)

# Create your views here.
class TipoEmpleadoViewSet(viewsets.ModelViewSet):
    queryset = TipoEmpleado.objects.all().order_by('id')
    serializer_class = TipoEmpleadoSerializer
    renderer_classes = [JSONRenderer]
class GeneroViewSet(viewsets.ModelViewSet):
    queryset = TipoGenero.objects.all().order_by('id')
    serializer_class = GeneroSerializer
    renderer_classes = [JSONRenderer]
class EmpleadoViewSet(viewsets.ModelViewSet):
    queryset = Empleado.objects.all().order_by('id')
    serializer_class = EmpleadoSerializer
    renderer_classes = [JSONRenderer]
    
def register(request):

    aux = { 
        'form': CustomUserCreationForm()
    }
    if request.method == 'POST':
        formulario = CustomUserCreationForm(data=request.POST)
        if formulario.is_valid():
            user = formulario.save()
            group = Group.objects.get(name='Usuario')
            user.groups.add(group)

            return redirect(to="login")
        else:
            aux["form"]= formulario

    return render(request, 'registration/register.html',aux)

def index(request):
    obras = Obra.objects.all()
    data = {
        'obras': obras
    }
    return render(request, 'core/index.html', data)


def login(request):
    return render(request, 'core/registration/login.html')

@permission_required('core.view_obra')
def gestion(request):
    obras = Obra.objects.all()
    
    data = { 
        'obras': obras
    }
    return render(request, 'core/imagenes/crud/gestion.html',data)

@permission_required('core.add_obra')
def agregar_autor(request):
    
    data = {
        'form':ObraForm()
    }

    if request.method == 'POST':
        formulario = ObraForm(data=request.POST, files=request.FILES)
        if formulario.is_valid():
            formulario.save()
            data["mensaje"] = "Solicitud enviada correctamente" 
        else:
            data["form"]= formulario

    return render(request, 'core/Imagenes/crud/add.html',data)


@permission_required('core.change_obra')
def modificar_obra(request, id_obra):
    obra = get_object_or_404(Obra, id_obra=id_obra)
    
    if request.method == 'POST':
        formulario = ObraForm(request.POST, request.FILES, instance=obra)
        if formulario.is_valid():
            # Si se guarda una nueva imagen, eliminamos la anterior antes 
            if 'imagen' in formulario.changed_data:
                # Eliminar la imagen anterior si existe
                if obra.imagen:
                    obra.imagen.delete()
            formulario.save()
            return redirect('gestion')
    else:
        formulario = ObraForm(instance=obra)
    
    return render(request, 'core/Imagenes/crud/modificar.html', {'form': formulario})

@permission_required('core.delete_obra')
def eliminar_obra(request, id_obra):
    obra = get_object_or_404(Obra, id_obra=id_obra)

    imagen_path = obra.foto.path

    obra.delete()

    if os.path.exists(imagen_path):
        os.remove(imagen_path)
    return redirect(to=gestion)


def contacto(request):
    data = {
        'form': ContactoForm()
    }
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data["mensaje"] = "Mensaje enviado!"
        else:
            data["form"]=formulario
            
    return render(request,'core/contacto.html',data)


def detalle(request, id_obra):
    obra = get_object_or_404(Obra, id_obra=id_obra)
    return render(request, 'core/detalle.html', {'obra': obra})





