from django.urls import path, include 
from .views import *
from rest_framework import routers

router = routers.DefaultRouter()
router.register('empleados', EmpleadoViewSet)
router.register('tipoempleados', TipoEmpleadoViewSet)
router.register('genero', GeneroViewSet)


urlpatterns = [
    path('', index, name='index'),
    path('login/', login , name='login'),
    path('gestion/', gestion, name='gestion'),
    path('autor/', agregar_autor, name='autor'),
    path('contacto/', contacto, name='contacto'),
    path('modificar/<id_obra>/', modificar_obra, name='modificar'),
    path('eliminar/<id_obra>/', eliminar_obra, name='eliminar'),
    path('detalle/<id_obra>/', detalle, name='detalle'),
    path('register/', register, name='register'), 
    #API
    path('api/', include(router.urls)),
    path('empleadosapi/', empleadosapi, name='empleadosapi'), 
    path('dineroapi/', dineroapi, name='dineroapi'), 
]
