function agregar() {
    Swal.fire({
        position: "top-end",
        icon: "Agregada!",
        title: "Tu obra ha sido subida",
        showConfirmButton: false,
        timer: 1500
      });
}
